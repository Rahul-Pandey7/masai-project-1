import React from "react"
import UserInterface from "./UserInterface";
import Input from "./Input";

export default class App extends React.Component {
    render() {
        return (
            <div>
                <h1 className="display-4">My Youtube Channel</h1>
                <div class="container">
                    <nav className="navbar navbar-expand-lg fixed-top color-blue bg-dark">
                        <a className="navbar-brand logo_h" href="final.html"><img src="download.png" style={{width: "85px", height:"85px;"}} />
                        </a>
                        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon"></span>
                        </button>
                        <div className="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul className="navbar-nav ml-auto color-blue">
                                <li className="nav-item active"><a className="nav-link color-blue" href="#">Notification</a>
                                </li>
                                <li><i className="fa fa-bells"></i></li>
                                <li className="nav-item "><a className="nav-link color-blue" href="#Project">Upload Video</a></li>
                                <li className="nav-item "><a className="nav-link color-blue" href="#">Share</a></li>
                                <li className="nav-item "><a className="nav-link color-blue" href="#Contact">Profile</a></li>
                            </ul>
                        </div>
                    </nav>
                </div>
                <div className="mt-4"></div>
                <Input />
                {/* <UserInterface /> */}
            </div>
        );
    }
}