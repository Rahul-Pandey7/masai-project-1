import React from "react";

export default class UserInterface extends React.Component {
    render() {
        return (
            <div>
                <div className="jumbotron" style={{backgroundImage: "linear-gradient(to right, #009fff, #ec2f4b)"}}>
                    <div className="row">
                        <div className="col col-12 col-lg-4">
                            <div className="card m-0 p-0">  
                                <iframe width="560" height="315" src="https://www.youtube.com/embed/KcBSDtfrdUI"
                                 frameBorder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowFullScreen></iframe>
                            </div>
                        </div>
                        <div className="col col-12 col-lg-4">
                            <div className="card m-0 p-0">
                                 <iframe width="560" height="315" src="https://www.youtube.com/embed/HWoRAxXRg14" frameBorder="0"
                                  allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowFullScreen></iframe>
                            </div>
                        </div>
                        <div className="col col-12 col-lg-4">
                            <div className="card">
                                <iframe width="560" height="315" src="https://www.youtube.com/embed/V5M2WZiAy6k" 
                                frameBorder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowFullScreen></iframe>
                            </div>
                        </div>
                    </div>
                    {/* <div className="row">
                        <div className="col col-12 col-lg-4">
                            <div className="card">
                                <iframe width="560" height="315" src="https://www.youtube.com/embed/1ZYbU82GVz4" frameBorder="0" 
                                allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowFullScreen></iframe>
                            </div>
                        </div>
                        <div className="col col-12 col-lg-4">
                            <div className="card">
                                <iframe width="560" height="315" src="https://www.youtube.com/embed/y7e-GC6oGhg"
                                 frameBorder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowFullScreen></iframe>
                            </div>
                        </div>
                        <div className="col col-12 col-lg-4">
                            <div className="card">
                                <iframe width="560" height="315" src="https://www.youtube.com/embed/PKIhyCzlKWU" 
                                frameBorder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowFullScreen></iframe>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col col-12 col-lg-4">
                            <div className="card">
                                <iframe width="560" height="315" src="https://www.youtube.com/embed/DLX62G4lc44" frameBorder="0"
                                 allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowFullScreen></iframe>
                            </div>
                        </div>
                        <div className="col col-12 col-lg-4">
                            <div className="card">
                                <iframe width="560" height="315" src="https://www.youtube.com/embed/KcBSDtfrdUI"
                                 frameBorder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowFullScreen></iframe>
                            </div>
                        </div>
                        <div className="col col-12 col-lg-4">
                            <div className="card">
                                <iframe width="560" height="315" src="https://www.youtube.com/embed/KcBSDtfrdUI"
                                 frameBorder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowFullScreen></iframe>
                            </div>
                        </div> */}
                    </div>
                </div>
        );
    }
}