import React from "react";
import axios from "axios";

export default class Input extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            keyword: "",
            collections: []
        }
    }

    get_video = (e) => {
        this.setState({
            keyword: e.target.value
        })
    }

    search = () => {
           method: 'get',
            url: "https://www.googleapis.com/youtube/v3/search/",
            params: {
                "key": "AIzaSyCYnz2BIh3II4v9LlDizrr6F2aj7LVCAU0",
                "part":"snippet",
                "maxResults":"25",
                "q": this.state.keyword,
            }
        })
            .then((response) => {
               console.log(response.data)
                console.log(response.data.pageInfo)
                this.setState({
                    collections:[...response.data.items],
                });
                

                // if (response.data.location_suggestions.length !== 0) {
                //     axios({
                //         method: 'get',
                //         url: "https://developers.zomato.com/api/v2.1/collections?city_id=" + loc_id,
                //         headers: {
                //             "user-key": "4e2d7fc281242798f244673aa36547b4",
                //         }
                //     })
                //         .then((response) => {
                //             console.log(response.data.collections)
                //             if (response.data.length !== 0) {
                //                 this.setState({
                //                     collections: { ...response.data.collections }

                //                 });
                //             }
                //         })
                // }
            })

    }

    render() {
        console.log(this.state.collections)
        return (
            <div>
                <div className="container">
                    <div className="row m-0 p-0">
                        <div className="col col-12 col-lg-10 m-0 p-0 text-center">
                            <input type="text" name="search" onChange={this.get_video}
                                 value={this.state.keyword}
                                placeholder="search videos.." />
                            <button type="button" 
                            onClick={this.search}>Search</button>
                        </div>
                    </div>
                </div><br /> <br />
                {this.state.collections.map((item)=> {
                    return (
                        <div key={item.id.videoId}>
                            <iframe width="560" height="315" src="https://www.youtube.com/embed/$`{item.id.videoId}`" frameBorder="0"
                                  allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowFullScreen></iframe>
                        </div>
                    )
                })
                }
            </div>
        );
    }
}